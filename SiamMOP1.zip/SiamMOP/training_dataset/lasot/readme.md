# Preprocessing LaSOT (train and val)


### Crop & Generate data info (20 min)

````shell
python parse_lasot.py
python par_crop.py 511 32
python gen_json.py
````
